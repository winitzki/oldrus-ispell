#!/bin/sh

# This script patches a distribution of "links" (a text-only Web browser), mostly to support old Russian orthography.

# Patching consists of: replacing some 7 bit values for Cyrillics to conform to Russkaya Latinica transliteration; adding old Russian language; silently replacing KOI8-R by KOI8-C; and replacing "awk" by "nawk" in "intl/synclang" and "Unicode/gen".

# "Russian bare" option in addition removes all languages except English, German and (old) Russian, renames ORussian to Russian, and removes all codepages except a small number.

# We need to have files "koi8_c.cp" and "oldrussian.lng" in current directory. Also we need to have "nawk" available.
bare=no

[ "X$1" = X-russianbare ] && {
	shift
	echo "-russianbare option given; will remove extra stuff not used in Russia."
	bare=yes
}


[ "X$1" = X ] && {
	echo "This script will patch 'links' for old Russian support."
	echo "Usage: $0 [-russianbare] {links-distro-dir}"
	echo "You will have to run 'configure' and 'make' after this script."
	exit
}

distro="$1"

test -d "$distro" || {
	echo "Cannot continue: '$distro' is not a directory"
	exit
}

test -f koi8_c.cp -a -f oldrussian.lng || {
	echo "Cannot continue: file 'koi8_c.cp' or 'oldrussian.lng' not found"
	exit
}

tmp=/tmp/tmp1.delete_me	# Temporary file name, will delete at the end

# Patch 7bitrepl.lnx to conform to Russkaya Latinica
file=7bitrepl.lnx
dir=Unicode
cp "$distro/$dir/$file" "$tmp"
cp "$distro/$dir/$file" "$distro/$dir/$file".orig
perl -e 'undef $/; $_=<STDIN>; s/0406:II/0406:I~/; s/0401:IO/0401:YO/; s/0429:SCH/0429:SHCH/; s/042a:\"/042a:~/; s/042d:\`E/042d:E'"'"'/; s/0449:sch/0449:shch/; s/044a:\"/044a:\~/; s/044d:\`e/044d:e'"'"'/; s/0451:io/0451:yo/; s/0456:ii/0456:i~/; s/0462:Y3/0462:E~/; s/0463:y3/0463:e~/; s/0472:F3/0472:~F/; s/0473:f3/0473:~f/; s/0474:V3/0474:~V/; s/0475:v3/0475:~v/; print;' < "$tmp" > "$distro/$dir/$file"

# Replace KOI8-R encoding by KOI8-C

file=koi8_r.cp
dir=Unicode
cp "$distro/$dir/$file" "$distro/$dir/$file".orig
sed -e 's/^KOI8-C/KOI8-R/' -e 's/koi8-c/koi8-r/g' < koi8_c.cp > "$distro/$dir/$file"

file=index.txt
dir=Unicode
cp "$distro/$dir/$file" "$distro/$dir/$file".orig
[ $bare = yes ] && {	# Strip unneeded encodings
	cat << "E2" > "$distro/$dir/$file"
7bit
8859_1
utf_8
koi8_r
koi8_u
8859_5
cp1250
cp1251
cp437
cp866
E2
}

# Add language "ORussian"
file=index.txt
dir=intl
cp "$distro/$dir/$file" "$distro/$dir/$file".orig
[ $bare = yes ] && cat << "E1" > "$distro/$dir/$file"
english
german
E1
echo "oldrussian" >> "$distro/$dir/$file"

file=oldrussian.lng
sed -e 's/koi8-c/koi8-r/' < oldrussian.lng > "$tmp"
[ $bare = yes ] && {	# Rename it to Russian in this case
	sed -e 's/ORussian/Russian/' < "$tmp" > "$tmp".1
	mv "$tmp.1" "$tmp"
}
mv "$tmp" "$distro/$dir/$file"

# Replace "awk" by "nawk" in some scripts

file=gen-7b
dir=Unicode
cp "$distro/$dir/$file" "$tmp"
cp "$distro/$dir/$file" "$distro/$dir/$file".orig
perl -e 'undef $/; $_=<STDIN>; s/(\s)awk(\s)/$1nawk$2/g; print;' < "$tmp" > "$distro/$dir/$file"

file=synclang
dir=intl
cp "$distro/$dir/$file" "$tmp"
cp "$distro/$dir/$file" "$distro/$dir/$file".orig
perl -e 'undef $/; $_=<STDIN>; s/(\s)awk(\s)/$1nawk$2/g; print;' < "$tmp" > "$distro/$dir/$file"


# Done

rm -f "$tmp"

cd "$distro"/intl
./synclang
cd ../Unicode
./gen

echo "Run 'configure --prefix=/usr --with-ssl' and 'make' now."

